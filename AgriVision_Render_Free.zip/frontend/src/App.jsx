import { useEffect, useState } from 'react';
import Navbar from './components/Navbar';
import Header from './components/Header';
import DiseaseCard from './components/DiseaseCard';
import YieldCard from './components/YieldCard';
import MarketCard from './components/MarketCard';

const API_BASE = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');
const INITIAL_STATUS = {
  api_available: false,
  disease_model_available: false,
  yield_model_available: false,
  disease_supported_categories: [],
  market_data_available: false,
};

function App() {
  const [modelStatus, setModelStatus] = useState(INITIAL_STATUS);
  const [yieldOptions, setYieldOptions] = useState(null);
  const [apiError, setApiError] = useState('');

  useEffect(() => {
    let cancelled = false;

    const loadStatus = async () => {
      try {
        const response = await fetch(`${API_BASE}/api/health`);
        if (!response.ok) throw new Error(`API health check failed (${response.status}).`);
        const status = await response.json();
        if (cancelled) return;
        setModelStatus({ ...status, api_available: true });
        setApiError('');

        if (status.yield_model_available) {
          const optionsResponse = await fetch(`${API_BASE}/api/yield/options`);
          if (!optionsResponse.ok) throw new Error(`Yield options unavailable (${optionsResponse.status}).`);
          const options = await optionsResponse.json();
          if (!cancelled) setYieldOptions(options);
        }
      } catch (error) {
        if (cancelled) return;
        setApiError(error.message || 'FastAPI backend is unavailable.');
      }
    };

    loadStatus();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <>
      <Navbar />
      <div className="dashboard-container">
        <Header modelStatus={modelStatus} apiError={apiError} />
        <div className="grid">
          <DiseaseCard modelStatus={modelStatus} />
          <YieldCard modelStatus={modelStatus} options={yieldOptions} />
          <MarketCard />
        </div>
      </div>
    </>
  );
}

export default App;
