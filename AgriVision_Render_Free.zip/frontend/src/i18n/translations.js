// Internationalisation placeholder.
// To add a new language, add a new key to each object below.

export const LANGUAGES = {
  en: 'English',
  hi: 'हिन्दी',
  mr: 'मराठी',
};

export const TRANSLATIONS = {
  en: {
    appName: 'AgriVision',
    disease: 'Disease Detection',
    yield: 'Yield Prediction',
    market: 'Market Insights',
    analyzeBtn: 'Analyze Leaf Image',
    forecastBtn: 'Forecast Yield',
    priceBtn: 'Get Live Prices',
  },
  hi: {
    appName: 'एग्रीविजन',
    disease: 'रोग पहचान',
    yield: 'उपज भविष्यवाणी',
    market: 'बाजार जानकारी',
    analyzeBtn: 'पत्ती छवि विश्लेषण करें',
    forecastBtn: 'उपज पूर्वानुमान',
    priceBtn: 'लाइव कीमत देखें',
  },
  mr: {
    appName: 'एग्रीविजन',
    disease: 'रोग शोध',
    yield: 'उत्पन्न अंदाज',
    market: 'बाजार माहिती',
    analyzeBtn: 'पानाचे विश्लेषण करा',
    forecastBtn: 'उत्पन्न अंदाज करा',
    priceBtn: 'थेट किंमत पाहा',
  },
};
