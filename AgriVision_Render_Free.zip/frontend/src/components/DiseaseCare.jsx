import ShopSearch from './ShopSearch';

const TOMATO = 'https://ipm.ucanr.edu/agriculture/tomato/';
const POTATO = 'https://ipm.ucanr.edu/agriculture/potato/';
const PEPPER = 'https://ipm.ucanr.edu/agriculture/peppers/';

export default function DiseaseCare({ category }) {
  if (!category || !category.includes('___')) return null;
  const healthy = category.endsWith('___healthy');
  const crop = category.startsWith('Potato') ? 'potato' : category.startsWith('Pepper') ? 'peppers' : 'tomato';
  let source = crop === 'potato' ? POTATO : crop === 'peppers' ? PEPPER : TOMATO;
  let steps = ['Ask a local agricultural extension officer to confirm the cause before selecting treatment. Take photos of both leaf surfaces and the whole plant.', 'Check nearby plants and record whether symptoms are spreading. Use the crop guide below to compare symptoms and management options.'];
  let supplies = ['Hand lens for inspecting leaves', 'Gloves and pruning tools for routine plant care'];
  if (healthy) {
    steps = ['No disease was identified among the model’s supported categories; this does not rule out other problems.', 'Continue checking the whole plant and use the crop guide for watering, planting and pest-management advice. Do not apply a pesticide solely because you used this app.'];
    supplies = ['Hand lens for routine monitoring'];
  } else if (category.includes('Bacterial_spot')) {
    source += 'bacterial-spot/';
    steps.push('Reduce leaf wetness and avoid overhead irrigation where practical. Use clean planting material and discuss crop-residue management with an adviser.');
  } else if (category.includes('Early_blight') || category.includes('Late_blight')) {
    source += category.includes('Early_blight') ? 'early-blight/' : 'late-blight/';
    steps.push('Discuss removal of volunteer tomato/potato plants and crop debris with an adviser. If blight is spreading rapidly, seek prompt local advice.');
  } else if (category.includes('Yellow_Leaf_Curl')) {
    source = 'https://www.agritech.tnau.ac.in/crop_protection/tomato_diseases_6.html';
    steps.push('Ask an adviser to check for whitefly vectors. Yellow sticky traps can support monitoring; they do not cure a virus-infected plant.');
    supplies = ['Yellow sticky traps for whitefly monitoring', 'Hand lens for inspecting leaf undersides'];
  } else if (category.includes('mosaic_virus')) {
    source = 'https://agritech.tnau.ac.in/crop_protection/tomato_diseases_12.html';
    steps.push('Consult the tomato mosaic management guide and get local advice on sanitation and crop rotation. Do not assume a spray will cure a viral infection.');
  } else if (category.includes('Septoria')) {
    source = 'https://agritech.tnau.ac.in/crop_protection/tomato_diseases_4.html';
  }
  return (
    <section className="result-note" aria-label="Disease care and supplies">
      <h3>{healthy ? 'Plant care and monitoring' : 'What to do next'}</h3>
      <p>General guidance based on the predicted label, not a confirmed diagnosis or guaranteed cure.</p>
      <ol>{steps.map(step => <li key={step}>{step}</li>)}</ol>
      <p><a href={source} target="_blank" rel="noopener noreferrer">Read the agricultural extension guide</a></p>
      <p>UC IPM guides describe California practice; pesticide registrations and conditions differ in India. TNAU guides may also contain older recommendations. Confirm any product against current local approval and its label with an agricultural adviser.</p>
      <h3>Where to find supplies</h3>
      <ul>{supplies.map(item => <li key={item}>{item}</li>)}</ul>
      <ShopSearch idPrefix="care-location" />
    </section>
  );
}
