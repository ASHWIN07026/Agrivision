import ShopSearch from './ShopSearch';

export default function SuppliesCard() {
  return (
    <section className="card module-card" id="supplies" aria-labelledby="supplies-title">
      <div className="card-header">
        <div className="card-icon supplies-icon" aria-hidden="true">⌖</div>
        <div>
          <h2 className="card-title" id="supplies-title">Find Supplies</h2>
          <p className="card-subtitle">Search the web for agricultural input shops near a location.</p>
        </div>
      </div>

      <div className="workbench-grid supplies-grid">
        <div className="workbench-form">
          <h3 className="section-title">Search nearby shops</h3>
          <p className="supporting-copy">
            Enter a town or district, or leave it blank to search near your current area.
          </p>
          <ShopSearch idPrefix="supplies-location" />
        </div>
        <aside className="trust-note">
          <h3>Before you buy</h3>
          <p>
            Search results are external listings, not recommendations. Sellers, licences, availability, stock, and prices
            have not been verified by AgriVision. Confirm product suitability and local approvals with a qualified
            agricultural adviser.
          </p>
        </aside>
      </div>
    </section>
  );
}
