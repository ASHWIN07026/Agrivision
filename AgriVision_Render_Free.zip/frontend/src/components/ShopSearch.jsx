import { useState } from 'react';

export default function ShopSearch({ idPrefix }) {
  const [location, setLocation] = useState('');
  const query = encodeURIComponent(`agricultural input shop ${location.trim() || 'near me'}`);

  return (
    <div className="shop-search">
      <label htmlFor={`${idPrefix}-input`}>Town or district (optional)</label>
      <div className="shop-search-row">
        <input
          id={`${idPrefix}-input`}
          className="form-control"
          type="search"
          value={location}
          onChange={(event) => setLocation(event.target.value)}
          placeholder="For example, Tiruppur"
          maxLength={100}
        />
        <a
          className="btn btn-secondary shop-search-button"
          href={`https://www.google.com/maps/search/?api=1&query=${query}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          Search nearby shops
        </a>
      </div>
      <p className="disclaimer">
        This opens an external search. AgriVision does not verify sellers, licences, stock, prices, or product suitability.
        Your location is sent only when you open the search link.
      </p>
    </div>
  );
}
