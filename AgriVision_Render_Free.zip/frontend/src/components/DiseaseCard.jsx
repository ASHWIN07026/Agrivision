import { useEffect, useState } from 'react';
import ResultBox from './ResultBox';
import DiseaseCare from './DiseaseCare';

const API_BASE = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');
const MAX_IMAGE_BYTES = 10 * 1024 * 1024;

function formatCategory(category) {
  return category
    .replace('Pepper,_bell', 'Bell pepper')
    .replace('___', ' — ')
    .replaceAll('_', ' ');
}

export default function DiseaseCard({ modelStatus }) {
  const [imagePreview, setImagePreview] = useState(null);
  const [fileName, setFileName] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!imagePreview) return undefined;
    return () => URL.revokeObjectURL(imagePreview);
  }, [imagePreview]);

  const handleImageChange = (event) => {
    const file = event.target.files?.[0];
    setResult(null);
    setError('');
    if (!file) {
      setImagePreview(null);
      setFileName('');
      return;
    }
    setFileName(file.name);
    setImagePreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setResult(null);
    setError('');
    const file = event.currentTarget.elements.namedItem('leaf-image')?.files?.[0];
    if (!file) {
      setError('Please upload a JPG or PNG leaf image.');
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      setError('Image exceeds the 10 MB limit.');
      return;
    }
    if (!modelStatus?.api_available) {
      setError('The local FastAPI backend is unavailable.');
      return;
    }
    if (!modelStatus?.disease_model_available) {
      setResult({ status: 'not_trained', disease: 'Model not trained', confidence: null });
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      const response = await fetch(`${API_BASE}/api/disease/predict`, { method: 'POST', body: formData });
      const data = await response.json();
      if (data?.status === 'not_trained') {
        setResult(data);
      } else if (!response.ok || data?.status !== 'ok') {
        throw new Error(data?.message || `Prediction failed (${response.status}).`);
      } else {
        setResult(data);
      }
    } catch (requestError) {
      setError(requestError.message || 'The model could not produce a prediction.');
    } finally {
      setLoading(false);
    }
  };

  const confidence = result?.confidence == null ? null : result.confidence * 100;

  return (
    <div className="card" id="disease">
      <div className="card-header">
        <div className="card-icon disease-icon">🔬</div>
        <div>
          <h2 className="card-title">Disease Detection</h2>
          <p className="card-subtitle">Classifies supported PlantVillage leaf categories</p>
        </div>
      </div>

      {modelStatus?.disease_supported_categories?.length > 0 && (
        <details className="result-note">
          <summary>View {modelStatus.disease_supported_categories.length} supported classes</summary>
          <ul>
            {modelStatus.disease_supported_categories.map((category) => (
              <li key={category}>{formatCategory(category)}</li>
            ))}
          </ul>
        </details>
      )}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="disease-file-input">Leaf image (JPG or PNG, up to 10 MB)</label>
          <div className="file-upload-wrapper">
            <div className={`upload-area ${imagePreview ? 'has-image' : ''}`}>
              {imagePreview ? (
                <div className="preview-container">
                  <img src={imagePreview} alt="Selected leaf preview" className="image-preview" />
                  <span className="file-name">{fileName}</span>
                </div>
              ) : (
                <div className="upload-placeholder">
                  <span className="upload-icon">📷</span>
                  <span className="upload-text">Choose a leaf image</span>
                  <span className="upload-hint">JPG or PNG</span>
                </div>
              )}
            </div>
            <input
              id="disease-file-input"
              name="leaf-image"
              type="file"
              accept=".jpg,.jpeg,.png,image/jpeg,image/png"
              onChange={handleImageChange}
              required
            />
          </div>
        </div>

        <button className="btn btn-disease" type="submit" disabled={loading}>
          {loading ? (
            <span className="btn-loading"><span className="spinner" />Analyzing...</span>
          ) : 'Analyze Leaf Image'}
        </button>
      </form>

      {error && <p className="error-msg" role="alert">⚠️ {error}</p>}

      {result && (
        <ResultBox title="🩺 Classification Result">
          <div className="result-row">
            <span className="result-label">Predicted class</span>
            <span className="result-value disease-name">
              {result.disease ? formatCategory(result.disease) : result.message}
            </span>
          </div>
          {confidence != null && (
            <>
              <div className="result-row">
                <span className="result-label">Model score (not test accuracy)</span>
                <span className="result-value">{confidence.toFixed(1)}%</span>
              </div>
              <div className="confidence-bar-bg" aria-hidden="true">
                <div className="confidence-bar" style={{ width: `${Math.min(confidence, 100)}%` }} />
              </div>
              <div className="result-row treatment">
                <span className="result-label">Model</span>
                <span className="result-value">{result.model_id}</span>
              </div>
              <div className="result-row treatment">
                <span className="result-label">Inference time</span>
                <span className="result-value">{Number(result.inference_ms).toFixed(1)} ms</span>
              </div>
              <p className="result-note">{result.guidance}</p>
              <DiseaseCare category={result.disease} />
            </>
          )}
          {result.status === 'not_trained' && <div className="status-banner">Model not trained</div>}
        </ResultBox>
      )}
    </div>
  );
}
