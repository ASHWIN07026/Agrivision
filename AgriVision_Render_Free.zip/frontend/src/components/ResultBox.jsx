export default function ResultBox({ title, children }) {
  return (
    <div className="result-box">
      <h4 className="result-title">{title}</h4>
      {children}
    </div>
  );
}
