export default function Header({ modelStatus, apiError }) {
  const diseaseReady = modelStatus?.disease_model_available;
  const yieldReady = modelStatus?.yield_model_available;
  const marketReady = modelStatus?.market_data_available === true;

  return (
    <header className="header">
      <div className="header-badge">AI-Powered Agriculture</div>
      <h1>AgriVision</h1>
      <p>Explore crop health, historical yield estimates, and local agricultural supplies.</p>

      <div className="status-row">
        <span className={`status-pill ${diseaseReady ? 'status-ready' : 'status-pending'}`} role="status">
          Disease model: {diseaseReady ? 'Ready' : modelStatus?.api_available ? 'Unavailable' : 'API unavailable'}
        </span>
        <span className={`status-pill ${yieldReady ? 'status-ready' : 'status-pending'}`} role="status">
          Yield model: {yieldReady ? 'Ready' : modelStatus?.api_available ? 'Unavailable' : 'API unavailable'}
        </span>
        <span className={`status-pill ${marketReady ? 'status-ready' : 'status-pending'}`} role="status">
          Live market data: {marketReady ? 'Available' : 'Unavailable'}
        </span>
      </div>
      {apiError && <p className="error-msg" role="status">{apiError}</p>}
    </header>
  );
}
