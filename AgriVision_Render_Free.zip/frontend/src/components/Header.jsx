export default function Header({ modelStatus, apiError }) {
  const diseaseReady = modelStatus?.disease_model_available;
  const yieldReady = modelStatus?.yield_model_available;
  const diseaseLabel = !modelStatus?.api_available
    ? 'API unavailable'
    : diseaseReady ? modelStatus.disease_model_id : 'Model not trained';
  const yieldLabel = !modelStatus?.api_available
    ? 'API unavailable'
    : yieldReady ? modelStatus.yield_model_id : 'Model not trained';

  return (
    <header className="header">
      <div className="header-badge">AI-Powered Agriculture</div>
      <h1>AgriVision</h1>
      <p>Plant disease classification and historical crop-yield estimation</p>

      <div className="header-stats">
        <div className="stat">
          <span className="stat-num">{diseaseReady ? 'Ready' : 'Unavailable'}</span>
          <span className="stat-label">Disease Model</span>
        </div>
        <div className="stat-divider" />
        <div className="stat">
          <span className="stat-num">{yieldReady ? 'Ready' : 'Unavailable'}</span>
          <span className="stat-label">Yield Model</span>
        </div>
        <div className="stat-divider" />
        <div className="stat">
          <span className="stat-num">Unavailable</span>
          <span className="stat-label">Live Market Data</span>
        </div>
      </div>

      <div className="status-row">
        <span className={`status-pill ${diseaseReady ? 'status-ready' : 'status-pending'}`}>
          Disease: {diseaseLabel}
        </span>
        <span className={`status-pill ${yieldReady ? 'status-ready' : 'status-pending'}`}>
          Yield: {yieldLabel}
        </span>
        <span className="status-pill status-pending">Market: Live market data unavailable</span>
      </div>
      {apiError && <p className="error-msg" role="status">{apiError}</p>}
    </header>
  );
}
