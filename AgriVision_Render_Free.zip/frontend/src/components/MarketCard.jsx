import { useState } from 'react';
import ResultBox from './ResultBox';

const API_BASE = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');
const CROP_OPTIONS = ['Tomato', 'Potato', 'Pepper', 'Rice', 'Wheat', 'Onion'];

export default function MarketCard({ modelStatus }) {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const marketAvailable = modelStatus?.market_data_available === true;

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError('');
    const formData = new FormData(event.currentTarget);
    const crop = formData.get('crop');
    const region = formData.get('region') || 'India';

    try {
      const query = new URLSearchParams({ crop, region });
      const response = await fetch(`${API_BASE}/api/market/price?${query}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data?.message || `Market request failed (${response.status}).`);
      setResult(data);
    } catch (requestError) {
      setError(requestError.message || 'Market lookup cannot be completed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="market-panel" aria-labelledby="market-title">
      <div className="market-heading">
        <div>
          <h2 className="card-title" id="market-title">Live Market Data</h2>
          <p className="card-subtitle">Separate from the external shop search.</p>
        </div>
        <span className={`status-pill ${marketAvailable ? 'status-ready' : 'status-pending'}`} role="status">
          {marketAvailable ? 'Available' : 'Currently unavailable'}
        </span>
      </div>
      {!marketAvailable && (
        <p className="market-unavailable">
          No verified live-market provider is connected. You can still check the service status below.
        </p>
      )}

      <form onSubmit={handleSubmit}>
        <div className="form-grid">
          <div className="form-group">
            <label htmlFor="market-crop">Crop</label>
            <select id="market-crop" name="crop" className="form-control" required>
              {CROP_OPTIONS.map((crop) => <option key={crop} value={crop}>{crop}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="market-region">Market or region</label>
            <input
              id="market-region"
              type="text"
              name="region"
              className="form-control"
              placeholder="e.g. Maharashtra"
              defaultValue="India"
            />
          </div>
        </div>

        <button className="btn btn-secondary" type="submit" disabled={loading}>
          {loading ? (
            <span className="btn-loading"><span className="spinner" />Checking…</span>
          ) : 'Check live-market status'}
        </button>
      </form>

      {error && <p className="error-msg" role="alert">⚠️ {error}</p>}

      {result && (
        <ResultBox title="Market lookup">
          {result.status === 'ok' && result.current_price != null ? (
            <>
              <div className="result-row">
                <span className="result-label">Crop / market</span>
                <span className="result-value">{result.crop} · {result.region || result.market}</span>
              </div>
              <div className="result-row">
                <span className="result-label">Price</span>
                <span className="result-value">{result.current_price} {result.units}</span>
              </div>
              <p className="result-note">Source: {result.source}</p>
              <p className="result-note">Updated: {result.updated_at}</p>
            </>
          ) : (
            <>
              <div className="status-banner">Live market data unavailable</div>
              <p className="result-note">{result.message || 'No verified live price is available.'}</p>
            </>
          )}
        </ResultBox>
      )}
    </section>
  );
}
