import { useRef } from 'react';

const PANELS = [
  { id: 'disease', label: 'Disease Detection' },
  { id: 'yield', label: 'Yield Estimation' },
  { id: 'supplies', label: 'Find Supplies' },
];

export default function Navbar({ activePanel, onPanelChange }) {
  const tabRefs = useRef([]);

  const handleKeyDown = (event, index) => {
    let nextIndex;
    if (event.key === 'ArrowRight') nextIndex = (index + 1) % PANELS.length;
    else if (event.key === 'ArrowLeft') nextIndex = (index - 1 + PANELS.length) % PANELS.length;
    else if (event.key === 'Home') nextIndex = 0;
    else if (event.key === 'End') nextIndex = PANELS.length - 1;
    else return;

    event.preventDefault();
    onPanelChange(PANELS[nextIndex].id);
    tabRefs.current[nextIndex]?.focus();
  };

  return (
    <nav className="navbar">
      <a className="navbar-brand" href="#main-content" aria-label="AgriVision home">
        <span className="navbar-logo">🌿</span>
        <span className="navbar-title">AgriVision</span>
      </a>
      <div className="navbar-links" role="tablist" aria-label="AgriVision tools" aria-orientation="horizontal">
        {PANELS.map((panel, index) => (
          <button
            key={panel.id}
            ref={(element) => { tabRefs.current[index] = element; }}
            id={`tab-${panel.id}`}
            className="nav-link"
            type="button"
            role="tab"
            aria-selected={activePanel === panel.id}
            aria-controls={`panel-${panel.id}`}
            tabIndex={activePanel === panel.id ? 0 : -1}
            onClick={() => onPanelChange(panel.id)}
            onKeyDown={(event) => handleKeyDown(event, index)}
          >
            {panel.label}
          </button>
        ))}
      </div>
    </nav>
  );
}
