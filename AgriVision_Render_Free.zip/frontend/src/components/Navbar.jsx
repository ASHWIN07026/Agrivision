export default function Navbar() {
  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <span className="navbar-logo">🌿</span>
        <span className="navbar-title">AgriVision</span>
      </div>
      <div className="navbar-links">
        <a href="#disease" className="nav-link">Disease</a>
        <a href="#yield" className="nav-link">Yield</a>
        <a href="#market" className="nav-link">Market</a>
      </div>
    </nav>
  );
}
