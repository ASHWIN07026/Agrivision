import { useState } from 'react';
import ResultBox from './ResultBox';

const API_BASE = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');

export default function YieldCard({ modelStatus, options }) {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    setResult(null);
    setError('');
    if (!modelStatus?.api_available) {
      setError('The local FastAPI backend is unavailable.');
      return;
    }
    if (!modelStatus?.yield_model_available || !options) {
      setResult({
        status: 'not_trained',
        message: 'Model not trained',
        expected_yield_kg_per_hectare: null,
      });
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/yield/predict`, {
        method: 'POST',
        body: new FormData(event.currentTarget),
      });
      const data = await response.json();
      if (data?.status === 'not_trained') {
        setResult(data);
      } else if (!response.ok || data?.status !== 'ok') {
        throw new Error(data?.message || `Prediction failed (${response.status}).`);
      } else {
        setResult(data);
      }
    } catch (requestError) {
      setError(requestError.message || 'The yield model could not produce a prediction.');
    } finally {
      setLoading(false);
    }
  };

  const defaultCountry = options?.countries?.includes('India')
    ? 'India'
    : options?.countries?.[0] || '';
  const yearRange = options?.accepted_prediction_year_range || options?.recommended_prediction_year_range || [];
  const datasetYearRange = options?.dataset_year_range || [];
  const datasetEndYear = datasetYearRange[1];
  const isExperimental = result?.estimate_type === 'experimental'
    || (result?.year != null && datasetEndYear != null && Number(result.year) > Number(datasetEndYear));

  return (
    <section className="card module-card" id="yield" aria-labelledby="yield-title">
      <div className="card-header">
        <div className="card-icon yield-icon" aria-hidden="true">🌾</div>
        <div>
          <h2 className="card-title" id="yield-title">Yield Estimation</h2>
          <p className="card-subtitle">Historical country and crop data, not a field-specific forecast.</p>
        </div>
      </div>

      <p className="scope-notice">
        Estimates use country or region, crop, and year. Soil, weather, and current market inputs are not included.
      </p>

      {modelStatus?.api_available && !modelStatus?.yield_model_available && (
        <div className="status-banner" role="status">Yield model unavailable</div>
      )}

      {options && datasetEndYear != null && (
        <>
          <p className="warning-banner" role="note">
            Years after {datasetEndYear} are experimental; future accuracy has not been validated.
          </p>
          <details className="disclosure">
            <summary>Dataset and model details</summary>
            <p>Saved dataset: {datasetYearRange.join('–')}. Training years: {options.train_year_range?.join('–') || 'Not provided'}.</p>
            <p>Later years may return identical values because the Random Forest does not extrapolate year trends.</p>
            <p>Model ID: {options.model_id || 'Not provided'}</p>
          </details>
        </>
      )}

      <div className="workbench-grid">
        <div className="workbench-form">
          <form key={options?.model_id || 'loading'} onSubmit={handleSubmit}>
            <div className="form-grid">
              <div className="form-group">
                <label htmlFor="yield-country">Country or FAO region</label>
                <select
                  id="yield-country"
                  name="country"
                  className="form-control"
                  defaultValue={defaultCountry}
                  required
                  disabled={!options}
                >
                  {options?.countries?.map((country) => (
                    <option key={country} value={country}>{country}</option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="yield-crop">Crop</label>
                <select
                  id="yield-crop"
                  name="crop"
                  className="form-control"
                  defaultValue={options?.crops?.[0] || ''}
                  required
                  disabled={!options}
                >
                  {options?.crops?.map((crop) => (
                    <option key={crop} value={crop}>{crop}</option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="yield-year">Target year</label>
                <input
                  id="yield-year"
                  type="number"
                  name="year"
                  className="form-control"
                  min={yearRange[0]}
                  max={yearRange[1]}
                  defaultValue={Math.min(new Date().getFullYear(), yearRange[1] || new Date().getFullYear())}
                  required
                  disabled={!options}
                />
                {yearRange.length === 2 && (
                  <span className="field-hint">Accepted input years: {yearRange[0]}–{yearRange[1]}</span>
                )}
              </div>
            </div>

            <button className="btn btn-primary" type="submit" disabled={loading || !options}>
              {loading ? (
                <span className="btn-loading"><span className="spinner" />Calculating…</span>
              ) : 'Estimate yield'}
            </button>
          </form>
          {error && <p className="error-msg" role="alert">{error}</p>}
        </div>

        <div className="workbench-result" aria-live="polite">
          {result ? (
            <ResultBox title="Yield estimate">
              {result.expected_yield_kg_per_hectare != null ? (
                <>
                  <div className="yield-display">
                    <span className="yield-number">
                      {Number(result.expected_yield_kg_per_hectare).toLocaleString()}
                    </span>
                    <span className="yield-unit">kg / hectare</span>
                  </div>
                  <div className="result-row">
                    <span className="result-label">Location and crop</span>
                    <span className="result-value">{result.country} · {result.crop} · {result.year}</span>
                  </div>
                  {isExperimental && (
                    <p className="warning-banner" role="status">
                      Experimental estimate: accuracy beyond the saved dataset is not validated.
                    </p>
                  )}
                  <details className="disclosure">
                    <summary>Estimate details</summary>
                    <p>{result.warning || 'Historical country/region estimate; not a field-specific forecast.'}</p>
                    <div className="result-row">
                      <span className="result-label">Model ID</span>
                      <span className="result-value">{result.model_id}</span>
                    </div>
                    <div className="result-row">
                      <span className="result-label">Inference time</span>
                      <span className="result-value">{Number(result.inference_ms).toFixed(1)} ms</span>
                    </div>
                  </details>
                </>
              ) : (
                <div className="status-banner">{result.message || 'Model not trained'}</div>
              )}
            </ResultBox>
          ) : (
            <div className="empty-state">
              <span className="empty-state-icon" aria-hidden="true">↗</span>
              <p>Your yield estimate will appear here.</p>
              <span>Choose a location, crop, and year.</span>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
