import { useState } from 'react';
import ResultBox from './ResultBox';

const API_BASE = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');

export default function YieldCard({ modelStatus, options }) {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    setResult(null);
    setError('');
    if (!modelStatus?.api_available) {
      setError('The local FastAPI backend is unavailable.');
      return;
    }
    if (!modelStatus?.yield_model_available || !options) {
      setResult({
        status: 'not_trained',
        message: 'Model not trained',
        expected_yield_kg_per_hectare: null,
      });
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/yield/predict`, {
        method: 'POST',
        body: new FormData(event.currentTarget),
      });
      const data = await response.json();
      if (data?.status === 'not_trained') {
        setResult(data);
      } else if (!response.ok || data?.status !== 'ok') {
        throw new Error(data?.message || `Prediction failed (${response.status}).`);
      } else {
        setResult(data);
      }
    } catch (requestError) {
      setError(requestError.message || 'The yield model could not produce a prediction.');
    } finally {
      setLoading(false);
    }
  };

  const defaultCountry = options?.countries?.includes('India')
    ? 'India'
    : options?.countries?.[0] || '';
  const yearRange = options?.recommended_prediction_year_range || [];

  return (
    <div className="card" id="yield">
      <div className="card-header">
        <div className="card-icon yield-icon">🌾</div>
        <div>
          <h2 className="card-title">Yield Estimation</h2>
          <p className="card-subtitle">Historical FAOSTAT country and crop records</p>
        </div>
      </div>

      <p className="result-note">
        Inputs are country/region, crop, and year. This dataset does not provide soil or weather features.
      </p>

      {modelStatus?.api_available && !modelStatus?.yield_model_available && (
        <div className="status-banner" role="status">Model not trained</div>
      )}

      <form key={options?.model_id || 'loading'} onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="yield-country">Country or FAO region</label>
          <select
            id="yield-country"
            name="country"
            className="form-control"
            defaultValue={defaultCountry}
            required
            disabled={!options}
          >
            {options?.countries?.map((country) => (
              <option key={country} value={country}>{country}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="yield-crop">Crop</label>
          <select
            id="yield-crop"
            name="crop"
            className="form-control"
            defaultValue={options?.crops?.[0] || ''}
            required
            disabled={!options}
          >
            {options?.crops?.map((crop) => (
              <option key={crop} value={crop}>{crop}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="yield-year">Target year</label>
          <input
            id="yield-year"
            type="number"
            name="year"
            className="form-control"
            min={yearRange[0]}
            max={yearRange[1]}
            defaultValue={yearRange[0]}
            required
            disabled={!options}
          />
          {yearRange.length === 2 && (
            <span className="upload-hint">
              Supported estimate range: {yearRange[0]}–{yearRange[1]}
            </span>
          )}
        </div>

        <button className="btn btn-yield" type="submit" disabled={loading || !options}>
          {loading ? (
            <span className="btn-loading"><span className="spinner" />Calculating...</span>
          ) : 'Estimate Yield'}
        </button>
      </form>

      {error && <p className="error-msg" role="alert">⚠️ {error}</p>}

      {result && (
        <ResultBox title="📊 Yield Estimate">
          {result.expected_yield_kg_per_hectare != null ? (
            <>
              <div className="yield-display">
                <span className="yield-number">
                  {Number(result.expected_yield_kg_per_hectare).toLocaleString()}
                </span>
                <span className="yield-unit">kg / hectare</span>
              </div>
              <div className="result-row">
                <span className="result-label">Location and crop</span>
                <span className="result-value">{result.country} · {result.crop} · {result.year}</span>
              </div>
              <div className="result-row">
                <span className="result-label">Model</span>
                <span className="result-value">{result.model_id}</span>
              </div>
              <div className="result-row">
                <span className="result-label">Inference time</span>
                <span className="result-value">{Number(result.inference_ms).toFixed(1)} ms</span>
              </div>
              <p className="result-note">Historical country/region estimate; not a field-specific forecast.</p>
            </>
          ) : (
            <div className="status-banner">{result.message || 'Model not trained'}</div>
          )}
        </ResultBox>
      )}
    </div>
  );
}
