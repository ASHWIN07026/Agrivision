# AgriVision: AI-Based Smart Agriculture Platform

AgriVision is a unified, AI-driven platform that integrates computer vision for crop disease detection, machine learning for yield prediction, and live market intelligence into a single dashboard. This allows farmers to make informed decisions before, during, and after the harvest without having to jump between disconnected tools.

## Features

1. **Early Disease Detection**: Upload a leaf image, and our CNN model will identify potential diseases (from 38 classes) and suggest treatments.
2. **Accurate Yield Forecasting**: Enter soil, rainfall, and temperature data to get a machine-learning-based forecast of your crop yield.
3. **Real-Time Market Insight**: Look up current market prices and demand trends so you can choose the best time and place to sell.
4. **Unified Dashboard**: All three modules communicate with a centralized FastAPI backend and are presented together on an intuitive React dashboard.

## Tech Stack

- **Frontend**: React, Vite
- **Backend**: FastAPI (Python)
- **Machine Learning**: TensorFlow (CNNs), Scikit-Learn (Regression)
- **Database**: Supabase / PostgreSQL

## Directory Structure

- `backend/`: FastAPI application containing all endpoints (`/api/disease/predict`, `/api/yield/predict`, `/api/market/price`).
- `frontend/`: React + Vite dashboard UI.
- `ml/`: Machine learning models and training scripts.
  - `disease/`: CNN model training scripts for disease detection.
  - `yield/`: Regression model training scripts for yield prediction.
- `data/`: Folder to hold datasets (raw, processed, etc.) and knowledge resources.
- `supabase/`: Database schemas and migrations.

## Getting Started

1. Set up your environment variables by copying `.env.example` to `.env`. See `api.txt` for instructions on acquiring required API keys.
2. **Backend Setup**:
   ```bash
   cd backend
   pip install -r requirements.txt
   uvicorn app.main:app --reload
   ```
3. **Frontend Setup**:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
4. **Model Training (Optional)**: If you don't have the model files, you can train dummy models using the provided scripts:
   ```bash
   python ml/disease/train_disease_model.py
   python ml/yield/train_yield_model.py
   ```
